Ninjago Alphabet Font v1.0 by LNP

================== DESCRIPTION ==================
This font was designed by LNP, following the inspiration from the Ninjago
Alphabet used in the show's world.

================== © NOTICE ==================
NINJAGO is a trademark and copyright of the LEGO Group.
©2022 The LEGO Group. All rights reserved.

================== FONT LICENSE ==================
The content owner grants the buyer a non-exclusive, perpetual, personal use
license to view, download, display, and copy the content, subject to the
following restrictions:

The content is licensed for personal use only, not commercial use. The
content may not be used in any way whatsoever in which you charge money,
collect fees, or receive any form of remuneration. The content may not be
resold, relicensed, sub-licensed, rented, leased, or used in advertising.

Title and ownership, and all rights now and in the future, of and for the
content remain exclusively with the content owner.

There are no warranties, express or implied. The content is provided 'as
is.'

Neither the content owner, payment processing service, nor hosting service
will be liable for any third party claims or incidental, consequential, or
other damages arising out of this license or the buyer's use of the content.

================== OTHER INFO ==================
For commercial use, please send an donation to my PayPal and an email to
projects@lnp-group.com with proof.